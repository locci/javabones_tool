package javax.el.test;

public interface TestInterface {
	public int getFourtyTwo(); 
}
